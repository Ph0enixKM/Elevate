
echo "Installing packages here..."
echo "Restarting service that runs the server..."

